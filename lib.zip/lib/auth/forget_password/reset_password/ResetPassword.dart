import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:graduation_project/App_Images/app_images.dart';
import 'package:graduation_project/Theme/dialog_utils.dart';
import 'package:graduation_project/Theme/theme.dart';
import 'package:graduation_project/auth/data/api/api_manager.dart';
import 'package:graduation_project/auth/data/repository/auth_repository/data_source/auth_remote_data_source_impl.dart';
import 'package:graduation_project/auth/data/repository/auth_repository/repository/auth_repository_impl.dart';
import 'package:graduation_project/auth/domain/repository/repository/auth_repository_contract.dart';
import 'package:graduation_project/auth/forget_password/reset_password/cubit/reset_password_viewmodel.dart';
import 'package:graduation_project/auth/forget_password/reset_password/cubit/reset_state.dart';
import 'package:graduation_project/auth/sing_in_screen/sign_in_screen.dart';
import 'package:graduation_project/auth/sing_in_screen/text_filed_login.dart';

class ResetPassword extends StatefulWidget {
  static const String routName = 'resetPassword';
  final String email; // تأكد من استقبال الإيميل عند التنقل إلى الشاشة

  const ResetPassword({super.key, required this.email});

  @override
  State<ResetPassword> createState() => _ResetPasswordState();
}

class _ResetPasswordState extends State<ResetPassword> {
  ResetPasswordScreenViewmodel viewmodel = ResetPasswordScreenViewmodel(
    repositoryContract: injectAuthRepositoryContract(),
  );

  @override
  void dispose() {
    viewmodel.passwordControllerOne.dispose();
    viewmodel.passwordControllerTwo.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<ResetPasswordScreenViewmodel, ResetPasswordState>(
      bloc: viewmodel,
      listener: (context, state) {
        if (state is ResetPasswordLoadingState) {
          DialogUtils.showLoading(context, state.loadingMassage!);
        } else if (state is ResetPasswordErrorState) {
          DialogUtils.hideLoading(context);
          DialogUtils.showMessage(context, state.errorMessage!,
              posActionName: 'Ok');
        } else if (state is ResetPasswordSuccessState) {
          DialogUtils.hideLoading(context);
          Navigator.of(context).pushReplacementNamed(
            SignInScreen.routName,
            arguments: viewmodel.passwordControllerOne.text,
          );
        }
      },
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          backgroundColor: Colors.transparent,
          title: Text(
            "Reset Password",
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ),
        body: Form(
          key: viewmodel.formKey,
          child: Padding(
            padding: const EdgeInsets.all(25),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Image.asset(
                    AppImages.sign,
                    width: 170,
                    height: 170,
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "Enter Your New Password",
                    textAlign: TextAlign.start,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 5),
                  TextFiledLogin(
                    controller: viewmodel.passwordControllerOne,
                    text: 'New Password',
                    icon: Icons.lock,
                    type: TextInputType.visiblePassword,
                    action: TextInputAction.done,
                    password: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Password is required";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  Text(
                    "Confirm Your Password",
                    textAlign: TextAlign.start,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 5),
                  TextFiledLogin(
                    controller: viewmodel.passwordControllerTwo,
                    text: 'Confirm Password',
                    icon: Icons.lock,
                    type: TextInputType.visiblePassword,
                    action: TextInputAction.done,
                    password: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "Password is required";
                      }
                      if (value != viewmodel.passwordControllerOne.text) {
                        return "Passwords do not match";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (viewmodel.formKey.currentState?.validate() == true) {
                        viewmodel.ResetPasssword(context, widget.email);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.all(11),
                      backgroundColor: MyTheme.orangeColor,
                    ),
                    child: Text(
                      textAlign: TextAlign.center,
                      "Reset Password",
                      style: Theme.of(context).textTheme.displaySmall,
                    ),
                  ),
                  const SizedBox(height: 50),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

AuthRepositoryContract injectAuthRepositoryContract() {
  return AuthRepositoryImpl(
      remoteDataSource:
      AuthRemoteDataSourceImpl(apiManager: ApiManager.getInstance()));
}
