import 'package:graduation_project/auth/data/model/response/ResetPassword/ResetPasswordResponse.dart';

abstract class ResetPasswordState {}

class ResetPasswordInitialState extends ResetPasswordState {}

class ResetPasswordLoadingState extends ResetPasswordState {
  String? loadingMassage;
  ResetPasswordLoadingState({this.loadingMassage});
}

class ResetPasswordSuccessState extends ResetPasswordState {
  ResetPasswordResponse resetPasswordResponse;
  ResetPasswordSuccessState({required this.resetPasswordResponse});
}

class ResetPasswordErrorState extends ResetPasswordState {
  String? errorMessage;
  ResetPasswordErrorState({this.errorMessage});
}
