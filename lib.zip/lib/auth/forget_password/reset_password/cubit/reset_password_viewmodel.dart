import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:graduation_project/auth/domain/repository/repository/auth_repository_contract.dart';
import 'package:graduation_project/auth/forget_password/reset_password/cubit/reset_state.dart';

class ResetPasswordScreenViewmodel extends Cubit<ResetPasswordState> {
  ResetPasswordScreenViewmodel({required this.repositoryContract})
      : super(ResetPasswordInitialState());

  TextEditingController passwordControllerOne = TextEditingController();
  TextEditingController passwordControllerTwo = TextEditingController();

  bool? value = false;
  GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final AuthRepositoryContract repositoryContract;

  void ResetPasssword(BuildContext context, String email) async {
    if (formKey.currentState?.validate() == true) {
      try {
        emit(ResetPasswordLoadingState(loadingMassage: "Loading..."));

        // تمرير الإيميل مع كلمة المرور الجديدة
        var response = await repositoryContract.resetpassword(
            email, passwordControllerOne.text);

        if (response.status == 'failure') {
          emit(ResetPasswordErrorState(errorMessage: response.message));
        } else {
          emit(ResetPasswordSuccessState(resetPasswordResponse: response));
        }
      } catch (e) {
        print("Error :=> $e");
        emit(ResetPasswordErrorState(errorMessage: e.toString()));
      }
    }
  }

  @override
  Future<void> close() {
    passwordControllerOne.dispose(); // تفريغ الحقل الأول
    passwordControllerTwo.dispose(); // تفريغ الحقل الثاني
    return super.close();
  }
}
