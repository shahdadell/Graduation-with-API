class RegisterresponseNew {
  String? status;
  String? message;
  String? userId;
  String? token;

  RegisterresponseNew({this.status, this.message, this.userId, this.token});

  factory RegisterresponseNew.fromJson(Map<String, dynamic> json) {
    return RegisterresponseNew(
      status: json['status'] as String?,
      message: json['message'] as String?,
      userId: json['user_id'] as String?,
      token: json['token'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'status': status,
        'message': message,
        'user_id': userId,
        'token': token,
      };
}
