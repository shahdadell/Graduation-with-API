class LoginResponse {
  String? status;
  String? message;
  String? userId;
  String? token;

  LoginResponse({this.status, this.message, this.userId, this.token});

  factory LoginResponse.fromJson(Map<String, dynamic> json) => LoginResponse(
        status: json['status'] as String?,
        message: json['message'] as String?,
        userId: json['user_id'] as String?,
        token: json['token'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'status': status,
        'message': message,
        'user_id': userId,
        'token': token,
      };
}
