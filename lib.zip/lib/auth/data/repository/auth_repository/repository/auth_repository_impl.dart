import 'package:graduation_project/auth/data/model/response/Login/LoginResponse.dart';
import 'package:graduation_project/auth/data/model/response/OTP/CheckEmailResponse.dart';
import 'package:graduation_project/auth/data/model/response/Register/registerresponse_new.dart';
import 'package:graduation_project/auth/data/model/response/Register/VerfiyCodeResponse.dart';
import 'package:graduation_project/auth/data/model/response/ResetPassword/ResetPasswordResponse.dart';
import 'package:graduation_project/auth/data/model/response/ResetPassword/VerfiyCodeForgetPasswordResponse.dart';
import 'package:graduation_project/auth/domain/repository/data_source/auth_remote_data_source.dart';
import 'package:graduation_project/auth/domain/repository/repository/auth_repository_contract.dart';
import 'package:graduation_project/local_data/shared_preference.dart';

class AuthRepositoryImpl implements AuthRepositoryContract {
  AuthRemoteDataSource remoteDataSource;
  AuthRepositoryImpl({required this.remoteDataSource});

  @override
  Future<RegisterresponseNew> register(
      String username, String password, String email, String phone) async {
    final response =
    await remoteDataSource.register(username, password, email, phone);
    if (response.status == 'success') {
      await AppLocalStorage.cacheData(AppLocalStorage.userNameKey, username);
      await AppLocalStorage.cacheData('userIdKey', response.userId);
      await AppLocalStorage.cacheData('tokenKey', response.token);
    }
    return response;
  }

  @override
  Future<LoginResponse> login(String email, String password) async {
    final response = await remoteDataSource.login(email, password);
    if (response.status == 'success') {
      await AppLocalStorage.cacheData('userIdKey', response.userId);
      await AppLocalStorage.cacheData('tokenKey', response.token);
      String? cachedUsername =
      AppLocalStorage.getData(AppLocalStorage.userNameKey) as String?;
      if (cachedUsername == null) {
        await AppLocalStorage.cacheData(AppLocalStorage.userNameKey, email);
      }
    }
    print("Response :=> $response");
    return response;
  }

  @override
  Future<CheckEmailResponse> checkemail(String email) {
    return remoteDataSource.checkemail(email);
  }

  @override
  Future<ResetPasswordResponse> resetpassword(String email, String password) {
    return remoteDataSource.resetpassword(email,password);
  }

  @override
  Future<VerfiyCodeResponse> verifyCode(String email, String verifyCode) {
    return remoteDataSource.verifyCode(email, verifyCode);
  }


  @override
  Future<VerfiyCodeForgetPasswordResponse> verifyCodeForgetPassword(
      String email, String verifyCode) {
    return remoteDataSource.verifyCodeForgetPassword(email, verifyCode);
  }

  // @override
  // Future<VerfiyCodeForgetPasswordResponse> verifyCodeForgetPassword(
  //     String email, String verifyCode) {
  //   return remoteDataSource.verifyCodeForgetPassword(email, verifyCode);
  // }
}
