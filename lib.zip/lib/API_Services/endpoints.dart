class AppEndpoints {
  //baseUrl
  static const String baseUrl = "https://abdulrahmanantar.com/outbye/";

  //auth
  static const String register = "auth/signup.php";
  static const String login = "auth/login.php";

  //Home
  static const String fetchHome = "home.php";

  //Services
  static const String fetchService = "services/services.php";

  //Items
  static const String fetchItems = "items/items.php";

  //Cart
  static const String addToCart = "cart/add.php";
  static const String cartCount = "cart/getcountitems.php";
  static const String viewCart = "cart/view.php";
  static const String cartDelete = "cart/delet.php";
}
