import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:graduation_project/home_screen/bloc/Cart/cart_bloc.dart';
import 'package:graduation_project/home_screen/bloc/Cart/cart_event.dart';
import 'package:graduation_project/home_screen/bloc/Cart/cart_state.dart';
import 'package:graduation_project/home_screen/data/model/Cart_model_response/cart_view_response/countprice.dart';
import 'package:graduation_project/home_screen/data/model/Cart_model_response/cart_view_response/datacart.dart';
import 'package:graduation_project/home_screen/data/repo/cart_repo.dart';

class CartScreen extends StatelessWidget {
  final int userId;

  const CartScreen({super.key, required this.userId});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => CartBloc(cartRepo: CartRepo()),
      child: BlocListener<CartBloc, CartState>(
        listener: (context, state) {
          if (state is CartInitialState) {
            // إضافة الـ event لجلب السلة عند البداية
            BlocProvider.of<CartBloc>(context)
                .add(FetchCartEvent(userId: userId));
          } else if (state is AddToCartSuccessState) {
            // إعادة جلب السلة بعد الإضافة الناجحة
            BlocProvider.of<CartBloc>(context)
                .add(FetchCartEvent(userId: userId));
          }
        },
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Cart'),
          ),
          body: BlocBuilder<CartBloc, CartState>(
            builder: (context, state) {
              if (state is FetchCartLoadingState) {
                return const Center(child: CircularProgressIndicator());
              } else if (state is FetchCartSuccessState) {
                final cart = state.cartViewResponse;
                if (cart.status == 'success') {
                  // عرض بيانات المطاعم إذا موجودة
                  if (cart.restCafe != null &&
                      cart.restCafe!.datacart != null) {
                    return _buildCartList(
                        cart.restCafe!.countprice, cart.restCafe!.datacart!);
                  }
                  // عرض بيانات الفنادق إذا موجودة
                  else if (cart.hotelTourist != null &&
                      cart.hotelTourist!.datacart != null) {
                    return _buildCartList(cart.hotelTourist!.countprice,
                        cart.hotelTourist!.datacart!.cast<Datacart>());
                  }
                  return const Center(
                      child: Text('Your cart is empty',
                          style: TextStyle(color: Colors.orange)));
                } else {
                  // رسالة عامة لو الـ status مش success
                  return const Center(
                      child: Text('An error occurred. Please try again.'));
                }
              } else if (state is FetchCartErrorState) {
                return Center(child: Text('Error: ${state.message}'));
              }
              return const Center(
                  child: Text('Your cart is empty',
                      style: TextStyle(color: Colors.orange)));
            },
          ),
        ),
      ),
    );
  }

  Widget _buildCartList(Countprice? countPrice, List<Datacart> dataCart) {
    return Column(
      children: [
        // عرض السعر الإجمالي وعدد المنتجات
        if (countPrice != null)
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Total Price: ${countPrice.totalprice ?? '0.00'} EGP',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Items: ${countPrice.totalcount ?? '0'}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        // عرض قايمة المنتجات
        Expanded(
          child: ListView.builder(
            itemCount: dataCart.length,
            itemBuilder: (context, index) {
              final item = dataCart[index];
              return ListTile(
                leading: const Icon(Icons.fastfood),
                title: Text(item.itemsName ?? 'No Name'),
                subtitle: Text(
                    'Price: ${item.itemsPrice ?? '0.00'} EGP | Quantity: ${item.cartQuantity ?? '0'}'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () {
                    // لو عندك endpoint للحذف نضيفه هنا
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
