import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:graduation_project/Theme/theme.dart';
import 'package:graduation_project/home_screen/UI/Cart_Page/CartScreen.dart';
import 'package:graduation_project/home_screen/bloc/Cart/cart_bloc.dart';
import 'package:graduation_project/home_screen/bloc/Cart/cart_event.dart';
import 'package:graduation_project/home_screen/bloc/Cart/cart_state.dart';
import 'package:graduation_project/home_screen/bloc/Home/home_bloc.dart';
import 'package:graduation_project/home_screen/bloc/Home/home_event.dart';
import 'package:graduation_project/home_screen/bloc/Home/home_state.dart';
import 'package:graduation_project/auth/sign_up_screen/sign_up_screen.dart';

class ServiceItemsScreen extends StatelessWidget {
  static const String routeName = 'ServiceItemsScreen';
  final int serviceId;
  final int userId;

  const ServiceItemsScreen({
    super.key,
    required this.serviceId,
    required this.userId,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => HomeBloc()
        ..add(FetchServiceItemsEvent(serviceId: serviceId, userId: userId)),
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Items"),
          backgroundColor: MyTheme.orangeColor,
        ),
        body: BlocBuilder<HomeBloc, HomeState>(
          builder: (context, homeState) {
            if (homeState is FetchServiceItemsLoadingState) {
              return const Center(child: CircularProgressIndicator());
            } else if (homeState is FetchServiceItemsSuccessState) {
              return Padding(
                padding: const EdgeInsets.all(10.0),
                child: BlocConsumer<CartBloc, CartState>(
                  listener: (context, cartState) {
                    if (cartState is AddToCartSuccessState) {
                      if (cartState.cartResponse.success == true) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                                'Added to cart! Quantity: ${cartState.cartResponse.quantity ?? 'N/A'}'),
                          ),
                        );
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => CartScreen(userId: userId)),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                                'Failed to add: ${cartState.cartResponse.message ?? 'Unknown error'}'),
                          ),
                        );
                      }
                    } else if (cartState is AddToCartErrorState) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error: ${cartState.message}')),
                      );
                    } else if (cartState is GetCartItemCountSuccessState) {
                      if (cartState.countResponse.status == 'success') {
                        // لو الكمية 0 يعني المنتج مش موجود، نضيفه
                        if (cartState.countResponse.quantity == 0) {
                          context.read<CartBloc>().add(
                                AddToCartEvent(
                                  userId: userId,
                                  itemId: cartState.itemId ?? 0,
                                ),
                              );
                        } else {
                          // لو المنتج موجود، نعرض رسالة
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                                content: Text(
                                    'Item already in cart! Quantity: ${cartState.countResponse.quantity}')),
                          );
                        }
                      }
                    } else if (cartState is GetCartItemCountErrorState) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error: ${cartState.message}')),
                      );
                    }
                  },
                  builder: (context, cartState) {
                    return GridView.builder(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        childAspectRatio: 0.8,
                      ),
                      itemCount: homeState.items.length,
                      itemBuilder: (context, index) {
                        final item = homeState.items[index];
                        return Card(
                          color: Colors.white,
                          elevation: 8,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: item.itemsImage != null &&
                                          item.itemsImage!.isNotEmpty
                                      ? Image.network(
                                          item.itemsImage!,
                                          height: 100,
                                          width: double.infinity,
                                          fit: BoxFit.cover,
                                        )
                                      : Container(
                                          height: 100,
                                          width: double.infinity,
                                          color: Colors.grey[300],
                                          child: const Icon(Icons.fastfood,
                                              size: 40, color: Colors.grey),
                                        ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  item.itemsName ?? 'No Name',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  item.itemsDes ?? 'No Description',
                                  style: TextStyle(
                                      fontSize: 12, color: Colors.grey[600]),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const Spacer(),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          '${item.itemsPrice?.toStringAsFixed(2) ?? 'N/A'} EGP',
                                          style: const TextStyle(
                                              color: Colors.green,
                                              fontSize: 14,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        if (item.itemsDiscount != null &&
                                            item.itemsDiscount! > 0)
                                          Text(
                                            '-${item.itemsDiscount?.toStringAsFixed(2)}%',
                                            style: const TextStyle(
                                                color: Colors.red,
                                                fontSize: 12,
                                                fontWeight: FontWeight.bold),
                                          ),
                                      ],
                                    ),
                                    IconButton(
                                      icon: Icon(
                                        item.favorite == 1
                                            ? Icons.favorite
                                            : Icons.favorite_border,
                                        color: item.favorite == 1
                                            ? Colors.red
                                            : Colors.grey,
                                      ),
                                      onPressed: () {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          const SnackBar(
                                              content:
                                                  Text('Added To Favorite!')),
                                        );
                                      },
                                    ),
                                    IconButton(
                                        icon: Icon(
                                          Icons.add_shopping_cart,
                                          color: cartState
                                                      is AddToCartLoadingState ||
                                                  cartState
                                                      is GetCartItemCountLoadingState
                                              ? Colors.grey
                                              : Colors.red,
                                        ),
                                        onPressed: (cartState
                                                    is AddToCartLoadingState ||
                                                cartState
                                                    is GetCartItemCountLoadingState)
                                            ? null
                                            : () {
                                                // التحقق من حالة المستخدم
                                                if (userId == 0 ||
                                                    userId == -1) {
                                                  Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            const SignUpScreen()),
                                                  );
                                                } else {
                                                  // التحقق من الكمية باستخدام getcountitems
                                                  if (item.itemsId != null) {
                                                    context
                                                        .read<CartBloc>()
                                                        .add(
                                                          GetCartItemCountEvent(
                                                            userId: userId,
                                                            itemId:
                                                                item.itemsId!,
                                                          ),
                                                        );
                                                  } else {
                                                    ScaffoldMessenger.of(
                                                            context)
                                                        .showSnackBar(
                                                      const SnackBar(
                                                          content: Text(
                                                              'Invalid item ID')),
                                                    );
                                                  }
                                                }
                                              }),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                ),
              );
            } else if (homeState is FetchServiceItemsErrorState) {
              return Center(
                  child: Text("Error: ${homeState.message}",
                      style: const TextStyle(color: Colors.red)));
            }
            return const SizedBox.shrink();
          },
        ),
      ),
    );
  }
}
